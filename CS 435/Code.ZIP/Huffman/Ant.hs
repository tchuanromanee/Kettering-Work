module Ant where

type Ants = Int

anteater :: Int -> Int

anteater x = x+1

aardvark = anteater
