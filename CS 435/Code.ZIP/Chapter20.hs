-----------------------------------------------------------------------
-- 	Haskell: The Craft of Functional Programming
-- 	Simon Thompson
-- 	(c) Addison-Wesley, 1999.

-- 	Chapter 20
-----------------------------------------------------------------------

-- Conclusion
-- ^^^^^^^^^^

-- This chapter contains nothing computational.

